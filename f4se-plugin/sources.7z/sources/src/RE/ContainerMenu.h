
namespace RE
{
	inline void OpenContainerMenu(const TESObjectREFR* a_refr, int a_menuMode, bool a_ownedNoCrime)
	{
		using func_t = decltype(&OpenContainerMenu);
		REL::Relocation<func_t> func{ REL::ID(1105206) };
		func(a_refr, a_menuMode, a_ownedNoCrime);
	}
}
