#pragma once

namespace Data
{
	enum ControlSystemType
	{
		kAnimationSystem,
		kAnimationGroupSystem,
		kPositionTreeSystem
	};
}
